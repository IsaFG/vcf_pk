## ----setup,include=FALSE,cache=FALSE-------------------------------------
require(knitr)
library(patchSynctex)
opts_knit$set(concordance = TRUE)
opts_knit$set(stop_on_error = 2L)
## next are for listings, to produce HTML
##listings-knitr-html%%options(formatR.arrow = TRUE)
##listings-knitr-html%%render_listings()

## ----packages,echo=FALSE,results='hide',message=FALSE--------------------
require(BiocStyle, quietly = TRUE)

## ----style-knitr, eval=TRUE, echo=FALSE, results="asis"------------------
BiocStyle::latex()

## ----create_p53, echo=FALSE, results='hide'------------------------------
set.seed(1)
dp53 <- data.frame(p53 = round(rnorm(23, c(rep(2, 13), rep(2.8, 10))), 3), 
                   pten = round(c(rlnorm(13, 1), rlnorm(10, 1.35)), 3),
                   brca1 = round(rnorm(23, c(rep(2, 13), rep(5.8, 10))), 3), 
                   brca2 = round(c(rep(c(1, 2, 3), length.out = 13),
                       rep(c(2, 3, 4), length.out = 10))),
                   cond = rep(c("Cancer", "NC"), c(13, 10)), 
                   id = replicate(23, paste(sample(letters, 10), collapse = "")))
write.table(dp53, file = "P53.txt", col.names = TRUE,
            row.names = FALSE, sep = "\t", quote = FALSE)
rm(list = ls())

## ------------------------------------------------------------------------
dp53 <- read.table("P53.txt", header = TRUE)

## ------------------------------------------------------------------------
library(car)
library(RcmdrMisc)

## ----out.width='11cm',out.height='11cm'----------------------------------
with(dp53, Hist(p53, groups = cond, col = "darkgray"))

## ----fig.height=10, fig.width=8,results='hide'---------------------------
op <- par(mfrow = c(2, 2)) ## to show 2 by 2 on the same figure
Boxplot(p53 ~ cond, data = dp53, id.method = "y")
plotMeans(dp53$p53, dp53$cond, error.bars = "se", 
  xlab = "Condition", ylab = "P53 expression levels")
stripchart(p53 ~ cond, vertical = TRUE, method = "jitter", 
  ylab = "p53", data = dp53)
densityPlot(p53 ~ cond, data = dp53, bw = "SJ", adjust = 1, 
  kernel = "gaussian")
par(op)

## ----fig.width=8, fig.height=8,echo=FALSE--------------------------------
scatterplotMatrix( ~ brca1 + brca2 + p53 + pten | cond, 
                  reg.line = FALSE, 
                  smooth = FALSE, 
                  data = dp53)

## ------------------------------------------------------------------------
t.test(p53 ~ cond, data = dp53)

## ------------------------------------------------------------------------
dp53$logpten <- log(dp53$pten)

## ----results='hide', fig.show='hold', fig.width=5, fig.height=5----------
op <- par(mfrow = c(1, 2))
Boxplot(pten ~ cond, data = dp53, id.method = "y")
Boxplot(logpten ~ cond, data = dp53, id.method = "y")
par(op)

## ------------------------------------------------------------------------
t.test(pten ~ cond, data = dp53)
t.test(logpten ~ cond, data = dp53)

## ----create_myc, echo=FALSE, results = 'hide'----------------------------
set.seed(15)
s <- rnorm(12, 4, 25)
s <- c(s, s)
cond <- rep(c(0, .5), c(12, 12))
y <- rnorm(24) + s + cond
y <- y - min(y) + 0.3
id <- replicate(12, paste(sample(letters, 10), collapse = ""))
id <- c(id, id)
dmyc <- data.frame(myc = round(y, 3), 
                   cond = rep(c("Cancer", "NC"), c(12, 12)), 
                   id = id)

## t.test(myc ~ cond, data = dmyc)
## ## should this work?? It does but from the help it ain't obvious to me
## t.test(myc ~ cond, paired = TRUE, data = dmyc) 
## t.test(myc ~ cond, data = dmyc)
## t.test(myc ~ cond, paired = TRUE, data = dmyc) 
## t.test(dmyc$myc[1:12] - dmyc$myc[13:24])
## summary(lm(myc ~ id + cond, data = dmyc))


write.table(dmyc, file = "MYC.txt", col.names = TRUE,
            row.names = FALSE, sep = "\t", quote = FALSE)

## ------------------------------------------------------------------------
dmyc <- read.table("MYC.txt", header = TRUE)

## ------------------------------------------------------------------------
all(with(dmyc, table(id, cond)) == 1)

## ------------------------------------------------------------------------
myc.cancer <- dmyc$myc[dmyc$cond == "Cancer"]
myc.nc <- dmyc$myc[dmyc$cond == "NC"]
t.test(myc.nc, myc.cancer, paired = TRUE)

## ------------------------------------------------------------------------
dmyc

## ------------------------------------------------------------------------
dmycO <- dmyc[order(dmyc$id, dmyc$cond), ]
dmycO
myc.cancer <- dmycO$myc[dmycO$cond == "Cancer"]
myc.nc <- dmycO$myc[dmycO$cond == "NC"]
t.test(myc.nc, myc.cancer, paired = TRUE)

## ------------------------------------------------------------------------
unstack(x = dmyc, form = myc ~  cond)

## ------------------------------------------------------------------------
dmyc0 <- dmyc[order(dmyc$cond, dmyc$id), ]
dmyc0

## ------------------------------------------------------------------------
merged2 <- unstack(dmyc0, form = myc ~ cond)
merged2

## ------------------------------------------------------------------------
(merged2$id <- dmyc0$id[1:12])

## ------------------------------------------------------------------------
(merged3 <- reshape(dmyc, direction = "wide", idvar = "id", 
                    timevar = "cond", v.names = "myc"))

## ------------------------------------------------------------------------
library(tidyr)
(merged4 <- spread(dmyc, cond, myc))

## ------------------------------------------------------------------------
## Paired
t.test(merged3$myc.NC, merged3$myc.Cancer, alternative='two.sided', 
       conf.level=.95,  paired=TRUE)

## ------------------------------------------------------------------------
## Two-sample
t.test(merged3$myc.NC, merged3$myc.Cancer, alternative='two.sided', 
       conf.level=.95,  paired=FALSE)

## ------------------------------------------------------------------------
t.test(myc ~ cond, alternative = 'two.sided', conf.level=.95, 
       var.equal=FALSE,  data=dmyc)


## ------------------------------------------------------------------------
diff.nc.c <- (myc.nc - myc.cancer)
t.test(diff.nc.c)

## ----fig.width=5.5, fig.height=5.5---------------------------------------
plotMeans(dmyc$myc, dmyc$cond, error.bars = "se", ylab = "MYC",
          xlab = "Condition")

## ----fig.width=5.5, fig.height=5.5, echo=TRUE, fig.show = 'hold'---------
Boxplot( ~ diff.nc.c, data = merged3, xlab = "",
         ylab = "Intra-subject difference (NC - Cancer)", main = "MYC")

## ----fig.show='hold'-----------------------------------------------------
stripchart(myc ~ cond, vertical = TRUE, data = dmyc)
for(i in unique(dmyc$id)) 
  segments(x0 = 1, x1 = 2, 
           y0 = dmyc$myc[dmyc$cond == "Cancer" & dmyc$id == i], 
           y1 = dmyc$myc[dmyc$cond == "NC" & dmyc$id == i], 
           col = "red")

## ----echo=TRUE,results='hide',eval=FALSE---------------------------------
## stripchart(myc ~ cond, vertical = TRUE, data = dmyc)
## f1 <- function(x) {
##     segments(x0 = 1, x1 = 2,
##              y0 = dmyc$myc[dmyc$cond == "Cancer" & dmyc$id == x],
##              y1 = dmyc$myc[dmyc$cond == "NC" & dmyc$id == x],
##              col = "red")
## }
## sapply(unique(dmyc$id), f1)

## ------------------------------------------------------------------------
LinearModel.1 <- lm(myc ~ id + cond, data = dmyc)
summary(LinearModel.1)

## ------------------------------------------------------------------------
Anova(LinearModel.1, type = "II")

## ------------------------------------------------------------------------
wilcox.test(p53 ~ cond, alternative = "two.sided", data = dp53)

## ------------------------------------------------------------------------
wilcox.test(myc.nc, myc.cancer, alternative = 'two.sided', paired = TRUE)

## ------------------------------------------------------------------------
wilcox.test(diff.nc.c)

## ------------------------------------------------------------------------
## Without logs
wilcox.test(dmyc$myc[1:12], dmyc$myc[13:24], paired = TRUE)
## After taking logs
wilcox.test(log(dmyc$myc[1:12]), log(dmyc$myc[13:24]), paired = TRUE)

## ----create_brca, echo=FALSE, results='hide'-----------------------------
set.seed(27)
n1 <- 8
n2 <- 5
nn <- 3
s <- rnorm(n1 + n2, 0, 2)
s <- rep(s, rep(nn, n1 + n2))
effect <- 1
cond.effect <- rep(c(0, effect), c(n1 * nn, n2 * nn))
cond <- rep(c("Cancer", "NC"), c(n1 * nn, n2 * nn))
y <- rnorm(length(cond.effect)) + s + cond.effect
y <- y - min(y) + 0.1
id <- replicate(n1 + n2, paste(sample(letters, 10), collapse = ""))
id <- rep(id, rep(nn, n1 + n2))
dbrca <- data.frame(brca2 = round(y, 3), 
                    cond = cond,
                    id = id)
## t.test(brca2 ~ cond, data = dbrca)
## aggbrca2 <- aggregate(dbrca[,c("brca2"), drop=FALSE], by=list(cond=dbrca$cond, 
##   id=dbrca$id), FUN=mean)
## t.test(brca2~cond, alternative='two.sided', conf.level=.95, var.equal=FALSE, 
##   data=aggbrca2)
## summary(aov(brca2 ~ cond + Error(id), data = dbrca))
## t.s <- summary(lmer(brca2 ~ cond + (1|id), data = dbrca))$coefficients[2, 3] ## t-statistic
## t.s
## t.s*t.s ## compare with aov

write.table(dbrca, file = "BRCA2.txt", col.names = TRUE,
            row.names = FALSE, sep = "\t", quote = FALSE)
rm(dbrca)

## ----echo=FALSE, results = 'hide'----------------------------------------
dbrca <- read.table("BRCA2.txt", header = TRUE)

## ------------------------------------------------------------------------
t.test(brca2 ~ cond, data = dbrca)

## ------------------------------------------------------------------------
aggbrca <- aggregate(dbrca[,c("brca2"), drop = FALSE],
                     by = list(cond = dbrca$cond, 
                         id = dbrca$id), FUN = mean)

## ------------------------------------------------------------------------
aggbrca <- aggregate(brca2 ~ cond + id, data = dbrca, FUN = mean)

## ------------------------------------------------------------------------
aggregate(brca2 ~ cond + id, data = dbrca, FUN = length)
aggregate(brca2 ~ id, data = dbrca, FUN = length)
aggregate(. ~ id, data = dbrca, FUN = length)

## ------------------------------------------------------------------------
t.test(brca2 ~ cond, alternative = 'two.sided', conf.level = .95, var.equal = FALSE, 
  data = aggbrca)

## ----create_mit, echo=FALSE, results='hide'------------------------------
set.seed(789)
n1 <- 11
n2 <- 12
n3 <- 23
m <- c(0, 0, 1.3)
activ <- rnorm(n1 + n2 + n3) + rep(m, c(n1, n2, n3))
activ <- activ - min(activ) + 0.2
mit <- data.frame(activ = round(activ, 3),
                  training = rep(c(1, 2, 3), c(n1, n2, n3)),
                  id = 1:(n1 + n2 +n3))
write.table(mit, file = "MIT.txt", col.names = TRUE,
            row.names = FALSE, sep = "\t", quote = FALSE)
rm(list = ls())

## ------------------------------------------------------------------------
dmit <- read.table("MIT.txt", header = TRUE)

## ------------------------------------------------------------------------
dmit$ftraining <- factor(dmit$training, 
                         labels = c('Morning','Lunch','Afternoon'))

## ----results='hide'------------------------------------------------------
Boxplot(activ ~ ftraining, data = dmit, id.method = "y")

## ----results='hide'------------------------------------------------------
AnovaMIT <- aov(activ ~ ftraining, data = dmit)
summary(AnovaMIT)

## ------------------------------------------------------------------------
numSummary(dmit$activ , groups = dmit$ftraining, statistics = c("mean", "sd"))

## ------------------------------------------------------------------------
with(dmit, aggregate(activ, list(Training = ftraining), 
                     function(x) c(mean = mean(x), 
                                   sd = sd(x), 
                                   n = sum(!is.na(x)))
                     ))

## ------------------------------------------------------------------------
with(dmit, by(activ, ftraining, 
              function(x) c(mean = mean(x), 
                             sd = sd(x), 
                             n = sum(!is.na(x)))
              ))

## ----tukey1,fig.cap='Plot of pairwise differences with Tukey contrasts', fig.lp='fig:', fig.width=5,fig.height=5, fig.show='hold', results='hide'----

library(multcomp) ## for glht
## The next two lines carry out the multiple comparisons and the following
## lines plot them
Pairs <- glht(AnovaMIT, linfct = mcp(ftraining = "Tukey"))
summary(Pairs) # pairwise tests
confint(Pairs) # confidence intervals
cld(Pairs) # compact letter display
old.oma <- par(oma = c(0,5,0,0))
plot(confint(Pairs))
par(old.oma) ## restore graphics windows settings

## ----out.width='9cm'-----------------------------------------------------
library(effects)
plot(allEffects(AnovaMIT), ask = FALSE)

## ----out.width='7cm', out.height='7cm', fig.show='hold'------------------
plot(allEffects(AnovaMIT), ask=FALSE, main = "Training: effect plot")

## ----out.width='7cm', out.height='7cm'-----------------------------------
.Pairs <- glht(AnovaMIT, linfct = mcp(ftraining = "Tukey"))
tmp <- cld(.Pairs) ## silent assignment 
plot(confint(.Pairs), 
     main = "95% family-wise confidence interval using Tukey contrasts")

## ------------------------------------------------------------------------
with(dmit, aggregate(activ, list(Training = ftraining), 
                      function(x) c(mean = mean(x), 
                                    sd = sd(x), 
                                    n = sum(!is.na(x)))
                      ))

## ------------------------------------------------------------------------
with(dmit, by(activ, ftraining, 
              function(x) c(mean = mean(x), 
                             sd = sd(x), 
                             n = sum(!is.na(x)))
              ))

## ------------------------------------------------------------------------
y <- c(1, 2, 3)
gr <- factor(c("g1", "g2", "g3"))
anova(lm(y ~ gr))
summary(aov(y ~ gr))

## ------------------------------------------------------------------------
y2 <- c(1, 2, 3, 4)
gr2 <- factor(c("g1", "g2", "g3", "g3"))
anova(lm(y2 ~ gr2))
summary(aov(lm(y2 ~ gr2)))

## ------------------------------------------------------------------------
p.values <- c(0.001, 0.01, 0.03, 0.05)
adjusted.p.values <- p.adjust(p.values, method = "BH")
cbind(p.values, adjusted.p.values)

## ------------------------------------------------------------------------
set.seed(3)
df1 <- data.frame(y = runif(8),
                  A = rep(c("a1", "a2"), 4),
                  B = rep(c("b1", "b1", "b2", "b2"), 2))


df1

## ------------------------------------------------------------------------
(means <- with(df1, tapply(y, list(A, B), mean)))

## ------------------------------------------------------------------------
m1 <- lm(y ~ A + B, data = df1)
anova(m1)

## ------------------------------------------------------------------------
summary(m1)

## ------------------------------------------------------------------------
m2 <- lm(y ~ A * B, data = df1)
anova(m2)

## ------------------------------------------------------------------------
summary(m2)

## ------------------------------------------------------------------------
means[2, 2] - 
    (means[1, 1] + coefficients(m2)[2] + coefficients(m2)[3])

## ------------------------------------------------------------------------
df2 <- df1[1:4, ]
m3 <- lm(y ~ A + B, data = df2)
anova(m3)
summary(m3)

## ------------------------------------------------------------------------
m4 <- lm(y ~ A * B, data = df2)
anova(m4)
summary(m4)

## ----create_tooth, echo=FALSE, results='hide'----------------------------

set.seed(45)
n <- c(4, 7, 9, 5, 7, 8)
m <- c(2.1, 1, 2, -.2, 4, 5)
y <- round(unlist(mapply(function(x, y) rnorm(x, y), n, m)), 3)
Drug <- c(rep("A", sum(n[1:3])),
          rep("B", sum(n[4:6])))
Diet <- rep(rep(c("HF", "M1", "M2"), 2), n)
chol <- data.frame(y = y,
                   Drug = Drug,
                   Diet = Diet)
rm(y, n, m, Drug, Diet)
## lm1 <- lm(y ~ Drug * Diet, data = chol)
## lm0 <- lm(y ~ Drug + Diet, data = chol)
## anova(lm1)
## Anova(lm1)
## anova(lm0)
## anova(lm(y ~ Diet + Drug, data = chol))
## Anova(lm0)
write.table(chol, file = "Cholesterol.txt", col.names = TRUE,
            row.names = FALSE, sep = "\t", quote = FALSE)
rm(chol)


## ------------------------------------------------------------------------
dcholest <- read.table("Cholesterol.txt", header = TRUE)

## ------------------------------------------------------------------------
## This fits the model. Pay attention to the "*"
cholestanova <- (lm(y ~ Diet*Drug, data=dcholest))
## This shows the ANOVA table. Notice the "Type II"
Anova(cholestanova)

## Now we are shown the 3 by 2 table of means, standard deviations, and number 
## of observations
tapply(dcholest$y, list(Diet=dcholest$Diet, Drug=dcholest$Drug), 
       mean, na.rm=TRUE) # means
tapply(dcholest$y, list(Diet=dcholest$Diet, Drug=dcholest$Drug), 
       sd, na.rm=TRUE) # std. deviations
tapply(dcholest$y, list(Diet=dcholest$Diet, Drug=dcholest$Drug), 
       function(x) sum(!is.na(x))) # counts

## ----out.width='12cm', out.height='12cm'---------------------------------
plot(allEffects(cholestanova), ask = FALSE)

## ----out.width = '8cm', out.height = '8cm'-------------------------------
with(dcholest, interaction.plot(Drug, Diet, y, type = "b"))

## ----out.width='14cm', out.height='14cm'---------------------------------
library(HH)
interaction2wt(y ~ Diet + Drug, data = dcholest)

## ----out.width='8cm', out.height='8cm', fig.show='hold'------------------
boxplot(y ~ Drug * Diet, data = dcholest, col = c("salmon", "gold"))
boxplot(y ~ Diet * Drug, data = dcholest, 
        col = c("salmon", "gold", "lightblue"))

## ------------------------------------------------------------------------
amodelnoint <- (lm(y ~ Diet + Drug, data=dcholest))
Anova(amodelnoint)

## ------------------------------------------------------------------------
dcholest2 <- subset(dcholest, subset = Diet != "HF")

## ------------------------------------------------------------------------
cholest2anova <- (lm(y ~ Diet*Drug, data = dcholest2))
Anova(cholest2anova)

## ------------------------------------------------------------------------
lm1 <- lm(y ~ Diet + Drug, data = dcholest2)
lm2 <- lm(y ~ Drug + Diet, data = dcholest2)

## ------------------------------------------------------------------------
anova(lm1)
anova(lm2)

## ------------------------------------------------------------------------
Anova(lm1)
Anova(lm2)

## ------------------------------------------------------------------------
set.seed(1)
sex <- factor(rep(c("Male", "Female"), c(20, 20)))
drug <- factor(rep(rep(c("A", "B"), c(10, 10)), 2))
y <- rep(c(10, 13, 12, 16), rep(10, 4))
y <- y + rnorm(length(y), sd = 1.5)
y.data <- data.frame(y, sex, drug)

## ------------------------------------------------------------------------
with(y.data, tapply(y, list(sex, drug), function(x) sum(!is.na(x))))
with(y.data, tapply(y, list(sex, drug), mean))

## ------------------------------------------------------------------------
summary(lm(y ~ sex * drug, data = y.data))

## ------------------------------------------------------------------------
m1 <- lm(y ~ sex + drug, data = y.data)
m2 <- lm(y ~ drug + sex, data = y.data)

## ------------------------------------------------------------------------
msex <- lm(y ~ sex, data = y.data)
mdrug <- lm(y ~ drug, data = y.data)

## ------------------------------------------------------------------------
summary(m1)
summary(m2)

## ------------------------------------------------------------------------
summary(msex)
summary(mdrug)

## ------------------------------------------------------------------------
anova(m1)
anova(m2)

## ------------------------------------------------------------------------
Anova(m1)

## ------------------------------------------------------------------------
anova(msex)
anova(mdrug)

## ------------------------------------------------------------------------

set.seed(3)
df1 <- data.frame(y = runif(6),
                  A = rep(c("a1", "a2", "a3"), 2),
                  B = rep(c("b1", "b2"), rep(3, 2)))
df1


## ------------------------------------------------------------------------
(means <- with(df1, tapply(y, list(A, B), mean)))

## ------------------------------------------------------------------------
m1 <- lm(y ~ A + B, data = df1)
anova(m1)
summary(m1)

## ------------------------------------------------------------------------
m2 <- lm(y ~ A * B, data = df1)
anova(m2)
summary(m2)
 

## ----create_anage, echo=FALSE, results='hide'----------------------------
anage_a_r <-  read.table("AnAge_birds_reptiles.txt", 
                         header = TRUE)


## ------------------------------------------------------------------------
anage_a_r$logMetabolicRate <- log(anage_a_r$Metabolic.rate..W.)
anage_a_r$logBodyMass <- log(anage_a_r$Body.mass..g.)
anage_a_r$logLongevity <- log(anage_a_r$Maximum.longevity..yrs.)

## ----create_anage_a, echo=FALSE, results='hide'--------------------------
anage_a <- anage_a_r[anage_a_r$Class == "Aves",]

## ------------------------------------------------------------------------
metab <- lm(Metabolic.rate..W. ~ Body.mass..g., data = anage_a)
summary(metab)

## ----out.width = '10cm', out.height = '10cm', results='hide'-------------
scatterplot(Metabolic.rate..W. ~ Body.mass..g., 
            smooth = TRUE, 
            spread = FALSE,  data = anage_a)

## ----out.width = '12cm', out.height = '12cm'-----------------------------
library(HH)
ci.plot(metab)

## ------------------------------------------------------------------------
metablog <- lm(logMetabolicRate ~ logBodyMass, data = anage_a)
summary(metablog)

## ----fig.width=7, fig.height=7,results='hide'----------------------------

scatterplot(Metabolic.rate..W. ~ Body.mass..g., log = "xy", 
            smooth = TRUE, spread = FALSE, 
            data = anage_a)

## ----fig.width=7, fig.height=7,out.width = '12cm', out.height = '12cm'----
ci.plot(metablog)

## ----echo=FALSE,results='hide'-------------------------------------------
data(cystfibr, package = "ISwR")
cystfibr2 <- cystfibr[, c("pemax", "age", "height", "weight", "sex")]
write.table(cystfibr2, file = "CystFibr2.txt", col.names = TRUE,
            row.names = FALSE, sep = "\t", quote = FALSE)
rm(cystfibr2)
rm(cystfibr)

## ------------------------------------------------------------------------
cystfibr2 <- read.table("CystFibr2.txt", header = TRUE)

## ------------------------------------------------------------------------
mcyst <- lm(pemax ~ age + height + weight, data=cystfibr2)
summary(mcyst)

## ------------------------------------------------------------------------
anova(mcyst)
Anova(mcyst)

## ----results='hide'------------------------------------------------------
scatterplotMatrix( ~ age+height+pemax+weight, smooth = TRUE, 
                  spread = FALSE,  data = cystfibr2)

## ------------------------------------------------------------------------
anova(lm(pemax ~ height + weight + age, data = cystfibr2))

## ------------------------------------------------------------------------
anova(lm(pemax ~ weight + height + age, data = cystfibr2))

## ------------------------------------------------------------------------
asAnova <- aov(activ ~ ftraining, data = dmit)
summary(asAnova)

## ------------------------------------------------------------------------
asLm <- lm(activ ~ ftraining, data = dmit)
anova(asLm)

## ------------------------------------------------------------------------
asLm
summary(asLm)

## ------------------------------------------------------------------------
means <- with(dmit, tapply(activ, ftraining, mean)) ## instead of "tapply", 
                                                    ## "by" or "aggregate" 
                                                    ## would 
                                                    ## also work here
means[1]
means[2] - means[1]
means[3] - means[1]
rm(means) ## let's remove it, so as not the leave
          ## garbage around

## ------------------------------------------------------------------------
dmitb <- dmit
dmitb$ftraining2 <- factor(dmitb$ftraining, 
                           levels = c("Afternoon", "Lunch", "Morning"))
## check
with(dmitb, table(ftraining, ftraining2))

## ------------------------------------------------------------------------
asLm2 <- lm(activ ~ ftraining2, data = dmitb)
anova(asLm2) ## no difference, of course
summary(asLm2)
meansb <- with(dmitb, tapply(activ, ftraining2, mean))
meansb[1]
meansb[2] - meansb[1]
meansb[3] - meansb[1]
rm(meansb)

## ------------------------------------------------------------------------
df1b <- df1
df1b$A <- factor(df1b$A, levels = c("a2", "a1"))
table(df1b$A, df1$A) ## double check

## ------------------------------------------------------------------------
summary(lm(y ~ A + B, data = df1b))

## ------------------------------------------------------------------------
y <- c(1:9, 20, 21, 22)
X <- rep(rep(c("x1", "x2"), c(3, 3)), 2)
U <- rep(c("u1", "u2"), c(6, 6))
anova(lm(y ~ U * X)) ## so strong evidence of interaction

## ------------------------------------------------------------------------
## The cell means
tapply(y, list(X, U), mean)
## The estimates
summary(lm(y ~ X * U))
## The intercept is the first cell mean.
## The right and bottom cell:
## the X2:U2 = 
21 - (2 + 3 + 6)
## The coefficient for x2 is the difference between the intercept and
## the first column of the second row:
5 - 2
## The coefficient for u2 is the difference between the intercept
## and the first row of the second column:
8 -2

## ------------------------------------------------------------------------
summary(mxu <- lm(y ~ X  + U))
model.matrix(mxu)
mean(y) ## 9
## What is the first cell? the overall mean with the effect of X:1 and
## U:1, which is the overall mean minus half the effects of X:2 and U:2

9 - 11/2 - 8/2 ## Where 11 and 8 are coming from the fitted model

fitted(mxu) ## Yes: fitted for first group are the intercept term


## But why the 11 and the 8 above?
## Again, look here:
(mxu <- tapply(y, list(X, U), mean))
## or here
aggregate(y ~ X * U, FUN = mean)

## And our model says: an overall mean, and row and column deviations. 
## Let's write it.
## Row effects, or effect of X:2 (effect of X:1 = - effect of X:2)
## is the average of the row differences at each column
## or average of (5 - 2) and (21 - 8) which is the effect of X:2
0.5 * ((5 - 2) + (21 - 8)) # = 8
## or, similarly
mean(mxu[2, ] - mxu[1, ])


## Similar for column effects, or the effect of U:2
## effect of U:2: 
0.5 * ((8 - 2) + (21 - 5)) # = 11
## or, similarly
mean(mxu[ , 2] - mxu[, 1])

## So the first cell is the first cell UNDER that additive model. You can't 
## just put the first cell mean in there.

## ------------------------------------------------------------------------
(means <- with(df1, tapply(y, list(A, B), mean)))

## ------------------------------------------------------------------------
summary(m2 <- lm(y ~ A * B, data = df1))
## each main effect
means[1, 2] - means[1, 1]
means[2, 1] - means[1, 1]
## interaction
means[2, 2] - ( means[1, 1] + (m2$coefficients[2] + m2$coefficients[3]))

## ------------------------------------------------------------------------
## Overall mean:
mean(df1$y)

## Note what are the estimates of the effects of A and B: the mean deviation
## of the second level from the first:
## A2 
mean(means[2, ] - means[1, ])
## B2
mean(means[, 2] - means[, 1])
## Intercept
mean(df1$y) - 
    0.5 * (mean(means[2, ] - means[1, ])) - 
    0.5 * mean(means[, 2] - means[, 1])

## ------------------------------------------------------------------------
opt <- options(contrasts = c("contr.Sum", "contr.poly"))
m11 <- lm(y ~ A + B, data = df1)
anova(m11)
summary(m11)

## ------------------------------------------------------------------------
(overallMean <- mean(df1$y))
mA <- with(df1, tapply(y, A, mean))
mA - overallMean

mB <- with(df1, tapply(y, B, mean))
mB - overallMean

## ------------------------------------------------------------------------
m12 <- lm(y ~ A * B, data = df1)
anova(m12)
summary(m12)

## ------------------------------------------------------------------------
summary(lm(y ~ A + B, data = df1b))

## ------------------------------------------------------------------------
options(opt)

## ------------------------------------------------------------------------
cystfibr2$sex <- factor(cystfibr2$sex, labels = c('Male','Female'))

## ------------------------------------------------------------------------
mcyst2 <- lm(pemax ~ age * sex, data = cystfibr2)
summary(mcyst2)
Anova(mcyst2)

## ----results='hide'------------------------------------------------------
scatterplot(pemax ~ age | sex, smooth = FALSE, data = cystfibr2)

## ------------------------------------------------------------------------
ancova(pemax ~ age * sex, data = cystfibr2)

## ------------------------------------------------------------------------
mcyst0 <- lm(pemax ~ age + sex, data = cystfibr2)
summary(mcyst0)
Anova(mcyst0)

## ------------------------------------------------------------------------
mcyst3 <- lm(pemax ~ age, data = cystfibr2)
anova(mcyst3, mcyst2)

## ------------------------------------------------------------------------
anova(mcyst0, mcyst2)

## ------------------------------------------------------------------------
anova(mcyst3, mcyst0)

## ------------------------------------------------------------------------
metab_b_r <- lm(logMetabolicRate ~ logBodyMass * Class, data = anage_a_r)
summary(metab_b_r)

## ------------------------------------------------------------------------
metab_b_r_2 <- lm(logMetabolicRate ~ logBodyMass + Class, data = anage_a_r)
summary(metab_b_r_2)
anova(metab_b_r_2, metab_b_r)

## ----results='hide'------------------------------------------------------
scatterplot(Metabolic.rate..W. ~ Body.mass..g. | Class, 
            log = "xy", smooth = FALSE, data = anage_a_r)

## ----fig.width=7, fig.height=7,echo=TRUE, results='hide'-----------------
ancova(logMetabolicRate ~ logBodyMass * Class, 
                data = anage_a_r)

## ------------------------------------------------------------------------
longev_b_r <- lm(logLongevity ~ logBodyMass * Class, data = anage_a_r)
summary(longev_b_r)

## ----results='hide'------------------------------------------------------
scatterplot(Maximum.longevity..yrs. ~ Body.mass..g. | Class, 
            smooth = FALSE, data = anage_a_r,
            log = "xy", boxplots = 'xy')

## ----echo=TRUE, results='hide'-------------------------------------------
ancova(logLongevity ~ logBodyMass * Class, data = anage_a_r)

## ------------------------------------------------------------------------
longev_b_r_2 <- lm(logLongevity ~ logBodyMass,  data = anage_a_r)
anova(longev_b_r_2, longev_b_r)

## ------------------------------------------------------------------------
set.seed(1) ## irrelevant, but so that we all 
            ## get the same numbers
n <- 20
sd <- 0.5

## ------------------------------------------------------------------------
z1 <- runif(n, 1, 10)
t1 <- factor(rep(c("g1", "g2"), rep(n, 2)))
y1 <-  2 * z1 + 3 * as.numeric(t1) + rnorm(n, 0, sd)
data1 <- data.frame(Y = y1, Z = z1, Group = t1, Ratio = y1/z1)

## ----fig.height=6,fig.cap='Parallel slopes but ratio differences?'-------
par(mfrow = c(1, 2))
with(data1, plot(Ratio ~ Group))
with(data1, plot(Y ~ Z, col = c("red", "blue")[Group]))
abline(lm(Y ~ Z, subset(data1, Group == "g1")), col = "red")
abline(lm(Y ~ Z, subset(data1, Group == "g2")), col = "blue")
legend(x = 3, y = 20, legend = c("g1", "g2"), col = c("red", "blue"),
       pch = 1)


## ------------------------------------------------------------------------
summary(lm(Y ~ Z * Group, data = data1))
t.test(Ratio ~ Group, data = data1)
## This is the equivalent to the t-test, except the
## t-test used by default by R does not assume equal variances
summary(aov(Ratio ~ Group, data = data1))

## ------------------------------------------------------------------------
set.seed(123)
sd <- 0.1
z2 <- seq(from = 1, to = 3, length.out = n)
ya <- z2 + rnorm(n, 0, sd)
yb <- 0.5 * z2 + 1 + rnorm(n, 0, sd)
y <- c(ya, yb)
tf <- factor(rep(c("g1", "g2"), rep(n, 2)))
z <- rep(z2, 2)
data2 <- data.frame(Y = y, Z = z, Group = tf, Ratio = y/z)

## ----fig.height=6,fig.cap='Different slopes and no ratio differences?'----
par(mfrow = c(1, 2))
with(data2, plot(Ratio ~ Group))
with(data2, plot(Y ~ Z, col = c("red", "blue")[Group]))
abline(lm(Y ~ Z, subset(data2, Group == "g1")), col = "red")
abline(lm(Y ~ Z, subset(data2, Group == "g2")), col = "blue")
legend(x = 1.5, y = 2.5, legend = c("g1", "g2"), col = c("red", "blue"),
       pch = 1)

## ------------------------------------------------------------------------
summary(lm(Y ~ Z * Group, data = data2))
t.test(Ratio ~ Group, data = data2) ## or do an ANOVA, as above

## ------------------------------------------------------------------------
## Create the data 
set.seed(1)
sex <- factor(rep(c("Male", "Female"), c(20, 20)))
drug <- factor(rep(rep(c("A", "B"), c(10, 10)), 2))
y <- rep(c(10, 13, 12, 16), rep(10, 4))
y <- y + rnorm(length(y), sd = 1.5)
y.data <- data.frame(y, sex, drug)
y.data[1, 1] <- 25
## Fit the model
myAdditive <- lm(y ~ sex + drug, data = y.data)
myInteract <- lm(y ~ sex * drug, data = y.data)
## What are they saying?
summary(myAdditive)
summary(myInteract)

## ----fig.show='hold', fig.cap='Model diagnostics for designed experiment, additive model '----
oldpar <- par(oma=c(0,0,3,0), mfrow=c(2,2))
plot(myAdditive)
par(oldpar)

## ----fig.show='hold', fig.cap='Model diagnostics for designed experiment, interaction model '----
oldpar <- par(oma=c(0,0,3,0), mfrow=c(2,2))
plot(myInteract)
par(oldpar)

## ----fig.show='hold', fig.cap='Model diagnostics for metabolic rate model without log transformation '----
oldpar <- par(oma=c(0,0,3,0), mfrow=c(2,2))
plot(metab)
par(oldpar)

## ----fig.show='hold', fig.cap='Model diagnostics for metabolic rate model after log transformation '----
oldpar <- par(oma=c(0,0,3,0), mfrow=c(2,2))
plot(metablog)
par(oldpar)

## ------------------------------------------------------------------------
## Diagnostics suggest missing interaction
set.seed(1)
sex <- factor(rep(c("Male", "Female"), c(20, 20)))
drug <- factor(rep(rep(c("A", "B"), c(10, 10)), 2))
y <- rep(c(8, 16, 10, 12), rep(10, 4))
y <- y + rnorm(length(y), sd = 1.5)
y.data1 <- data.frame(y, sex, drug)
rm(y, sex, drug)
with(y.data1, tapply(y, list(sex, drug), mean))

## Fit the model
myAdditive2 <- lm(y ~ sex + drug, data = y.data1)
myInteract2 <- lm(y ~ sex * drug, data = y.data1)
summary(myAdditive2)
summary(myInteract2)

## ----fig.cap='Additive model, myAdditive2,  when there is interaction'----
par(mfrow = c(2, 3))
plot(myAdditive2, which = c(1:5)) ## look at first plot

## ----fig.cap='Interaction model, myInteract2, when there is interaction'----
par(mfrow = c(2, 3))
plot(myInteract2, which = c(1:5))

## ------------------------------------------------------------------------
############
## Large cook's in anova
set.seed(1)
sex <- factor(rep(c("Male", "Female"), c(20, 20)))
drug <- factor(rep(rep(c("A", "B"), c(10, 10)), 2))
y <- rep(c(8, 12, 11, 15), rep(10, 4))
y <- y + rnorm(length(y), sd = 1.5)
y.data2 <- data.frame(y, sex, drug)
rm(y, sex, drug)
## create a large outlier

y.data2[1, 1] <- 30
with(y.data2, tapply(y, list(sex, drug), mean))

## ## Fit the model
myAdditive2b <- lm(y ~ sex + drug, data = y.data2)
## myInteract <- lm(y ~ sex * drug, data = y.data2)
## summary(myAdditive)
## summary(myInteract)

## ----fig.cap='myAdditive2b: large Cook with balanced data'---------------
## ## diagnostics, all of them except 6th
## we actually have a large Cook's distance
par(mfrow = c(2, 3))
plot(myAdditive2b, which = 1:5)

## ------------------------------------------------------------------------
## model with and without first obs
summary(lm(y ~ sex + drug, data = y.data2))
summary(lm(y ~ sex + drug, data = y.data2[-1, ]))

## ----fig.cap='myAdditive2b removing the large offending value'-----------
#### Diagnostics if we remove the offending value
par(mfrow = c(2, 3))
plot(lm(y ~ sex + drug, data = y.data2[-1, ]), which = 1:5)

## ------------------------------------------------------------------------
## The model with two observations missing
## create unbalance
y.data3 <- y.data2[-c(35, 40), ]
with(y.data3, tapply(y, list(sex, drug), mean))
myAdditive3 <- lm(y ~ sex + drug, data = y.data3)

## ----fig.cap='myAdditive3: missing two observations'---------------------
par(mfrow = c(2, 3))
plot(myAdditive3, which = 1:5) ## see Cook's

## ----echo=TRUE,results='hide'--------------------------------------------
## some details, from plot.lm
(hii2b <- lm.influence(myAdditive2b, do.coef = FALSE)$hat) ## constant
(hii3 <- lm.influence(myAdditive3, do.coef = FALSE)$hat) ##nope

## ------------------------------------------------------------------------
diff(range(hii2b))
diff(range(hii3))

## ------------------------------------------------------------------------
step(mcyst2, direction = "both")

## ------------------------------------------------------------------------
step(mcyst, direction = "both")

## ------------------------------------------------------------------------
## In metab, we drop the interaction
step(metab_b_r, direction = "both")
 
## But nothing can be dropped here
step(longev_b_r, direction = "both")

## ------------------------------------------------------------------------
lmMITnofactor <- lm(activ ~ training, data = dmit)
summary(lmMITnofactor)
Anova(lmMITnofactor)

## ----echo=FALSE,results='hide',error=FALSE-------------------------------
options(width = 60)

## ------------------------------------------------------------------------
sessionInfo()

